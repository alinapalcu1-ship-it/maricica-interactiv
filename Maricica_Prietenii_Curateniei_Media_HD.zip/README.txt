Cele patru scene ale poeziei Prietenii curățeniei și cele 9 înregistrări MP3 ElevenLabs ale utilizatoarei.
Fiecare MP3 corespunde titlului (1) sau unuia dintre cele opt versuri (2–9).
Versiunea V10 a poveștii și jocurile nu se modifică.
